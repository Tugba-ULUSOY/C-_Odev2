﻿/******************************************************************
**			SAKARYA ÜNİVERSİTESİ
**          BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**          BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**          PROGRAMLAMAYA GİRİŞ ÖDEVİ
**     Ödev Numarası        :	2-2
**     Öğrenci Adı          : TUĞBA ULUSOY
**     Öğrenci Numarası		: G171210017
**     Ders Grubu           :	A
********************************************************************/
#include< iostream>
#include< stdlib>
using namespace std;
int main(int argc, char*argv[])
{
	int i;
	for (int i = 1; i <2; i == )
	{
		for (int a = 0; a<10; a++)
			cout <<  rand() << endl;
	}
	switch (x)
	{
	case (a || A): cout << ” aşağı ” << endl;
		break;
	case (d || D): cout << ” yukarı ” << endl;
		break;
	case (c || C): cout << ” programdan çık ” << endl;
		break;
	}
	int a[N];
	cout << " Bir sayi giriniz ";
	cin >> Bir sayi;
	cout << endl;
	cout << " Bir x değeri giriniz ";

	system("PAUSE");
	return 0;
}


