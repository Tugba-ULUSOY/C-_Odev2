﻿/******************************************************************               
**			SAKARYA ÜNİVERSİTESİ
**          BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**          BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**          PROGRAMLAMAYA GİRİŞ ÖDEVİ
**     Ödev Numarası        :	2-3
**     Öğrenci Adı          : TUĞBA ULUSOY
**     Öğrenci Numarası		: G171210017
**     Ders Grubu           :	A
********************************************************************/
#include<iostream>
#include<Math.h>
using namespace std;
int main()
{
	int aa, bb, cc;
	float Delta, kok1, kok2 ;
	cout << "Bir aa degeri giriniz : ";
	cin >> aa;
	cout << "Bir bb degeri giriniz : ";
	cin >> bb;
	cout << "Bir cc degeri giriniz : ";
	cin >> cc;
	Delta = ((bb*bb)-(4 * aa*cc));
	cout << " Delta = " <<Delta<< endl;
	if (Delta > 0)
	{
		kok1 = (-bb-sqrt(Delta)) / (2 * aa);
		kok2 = (-bb + sqrt(Delta)) / (2 * aa);
		cout << " kok 1 = " <<kok1<< endl;
		cout << " kok 2 = " <<kok2<< endl;
	}
	else if (Delta < 0)
		cout << " Reel sayilarda kok yoktur " << endl;
	else if (Delta == 0)
	{
		cout << " cakisik iki koku vardir " << endl;
	
		kok1 = (-bb-sqrt(Delta)) / (2 * aa);
		kok2 = (-bb+sqrt(Delta)) / (2 * aa);
		cout << " kok 1 = " <<kok1<< endl;
		cout << " kok 2 = " <<kok2<<endl;
	}
	system(" PAUSE ");
	return  EXIT_SUCCESS;
}