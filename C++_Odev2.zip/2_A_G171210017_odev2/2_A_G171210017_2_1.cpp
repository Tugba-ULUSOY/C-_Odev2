﻿/******************************************************************
**			SAKARYA ÜNİVERSİTESİ
**          BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**          BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**          PROGRAMLAMAYA GİRİŞ ÖDEVİ
**     Ödev Numarası        :	2-1
**     Öğrenci Adı          : TUĞBA ULUSOY
**     Öğrenci Numarası		: G171210017
**     Ders Grubu           :	A
********************************************************************/
#include< iostream>
using namespace std;
int main()
{
	double vize_notu, odev_notu_1, odev_notu_2, kisa_sinav_notu_1, kisa_sinav_notu_2, final_sinavi_notu, vize_yil_icine_etkisi, kisa_sinav_yil_icine_etkisi, odevlerin_yil_icine_etkisi, yil_ici_puaninin_etkisi;
		cout << "vize notunu giriniz ........................................... ";
		cin >> vize_notu;
		cout << endl;
		cout << "odev notu 1 giriniz ........................................... ";
		cin >> odev_notu_1;
		cout << endl;
		cout << "odev notu 2 giriniz............................................ ";
		cin >> odev_notu_2;
		cout << endl;
		cout << "kısa sınav notu 1 giriniz: .................................... ";
		cin >> kisa_sinav_notu_1;
		cout << endl;
		cout << "kısa sınav notu 2 giriniz...................................... ";
		cin >> kisa_sinav_notu_2;
		cout << endl;
		cout << "final sinavi notu giriniz...................................... ";
		cin >> final_sinavi_notu;
		cout << endl;
		cout << "vizenin yil içine etkisi kaç olacaktir ........................ ";
		cin >> vize_yil_icine_etkisi;
		cout << endl;
		cout << "odevlerin yil icine etkisi kac olacaktir....................... ";
		cin >> odevlerin_yil_icine_etkisi;
		cout << endl;
		cout << "kisa sinavlarin yil içine etkisi kaç olacaktır ................ ";
		cin >> kisa_sinav_yil_icine_etkisi;
		cout << endl;
		cout << "yil içi puanin etkisi kaç olacaktır............................ ";
		cin >> yil_ici_puaninin_etkisi;
		cout << endl;
		double Not1;
		Not1=(((kisa_sinav_notu_1 + kisa_sinav_notu_2)*(kisa_sinav_yil_icine_etkisi))/200) ;
		double Not2;
		Not2 = ((odev_notu_1 + odev_notu_2)*(odevlerin_yil_icine_etkisi / 200));
		double Not3;
		Not3=((vize_notu*vize_yil_icine_etkisi) / 100 );
		double Yil_ici;
		Yil_ici =Not1 + Not2 + Not3 ;
		double Basari_Notu;
		Basari_Notu = ((Yil_ici* yil_ici_puaninin_etkisi/100) + (100-yil_ici_puaninin_etkisi)/100*(final_sinavi_notu));
		cout << Basari_Notu;
		if(Basari_Notu >= 90 & Basari_Notu <= 100)
		cout << "   AA";
		else if (Basari_Notu >= 85 & Basari_Notu <= 89)
		cout << "   BA";
		else if (Basari_Notu >= 80 & Basari_Notu <= 84)
		cout << "   BB";
		else if (Basari_Notu >= 75 & Basari_Notu <= 79)
		cout << "   CB";
		else if (Basari_Notu >= 65 & Basari_Notu <= 74)
		cout << "   CC";
		else if (Basari_Notu >= 58 & Basari_Notu <= 64)
		cout << "   DC";
		else if (Basari_Notu >= 50 & Basari_Notu <= 57)
		cout << "   DD";
		else if (Basari_Notu >= 0 & Basari_Notu <= 49)
		cout << "   FF";
		else if (Basari_Notu = 0.00)
		cout << "   GR |    DZ";
		system(" PAUSE");
		return EXIT_SUCCESS;
}